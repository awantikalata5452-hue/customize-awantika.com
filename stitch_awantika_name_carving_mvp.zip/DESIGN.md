---
name: Artisanal Woodcraft Identity
colors:
  surface: '#fbf9f4'
  surface-dim: '#dbdad5'
  surface-bright: '#fbf9f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ee'
  surface-container: '#f0eee9'
  surface-container-high: '#eae8e3'
  surface-container-highest: '#e4e2dd'
  on-surface: '#1b1c19'
  on-surface-variant: '#4f453f'
  inverse-surface: '#30312e'
  inverse-on-surface: '#f2f1ec'
  outline: '#81756e'
  outline-variant: '#d2c4bc'
  surface-tint: '#705a4c'
  primary: '#26170c'
  on-primary: '#ffffff'
  primary-container: '#3d2b1f'
  on-primary-container: '#ac9181'
  inverse-primary: '#dec1af'
  secondary: '#775a19'
  on-secondary: '#ffffff'
  secondary-container: '#fed488'
  on-secondary-container: '#785a1a'
  tertiary: '#2c1403'
  on-tertiary: '#ffffff'
  tertiary-container: '#452813'
  on-tertiary-container: '#b88e72'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#fbddca'
  primary-fixed-dim: '#dec1af'
  on-primary-fixed: '#28180d'
  on-primary-fixed-variant: '#574335'
  secondary-fixed: '#ffdea5'
  secondary-fixed-dim: '#e9c176'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5d4201'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ecbd9f'
  on-tertiary-fixed: '#2e1503'
  on-tertiary-fixed-variant: '#603f29'
  background: '#fbf9f4'
  on-background: '#1b1c19'
  surface-variant: '#e4e2dd'
typography:
  display-lg:
    fontFamily: EB Garamond
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: EB Garamond
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-md:
    fontFamily: EB Garamond
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: EB Garamond
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.0'
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
---

## Brand & Style
The brand personality is rooted in the intersection of heritage craftsmanship and modern luxury. It evokes the tactile, olfactory experience of a master woodworker’s studio—precise, intentional, and timeless. The design style follows a **Modern Tactile** approach, blending high-end editorial layouts with organic, physical textures. It avoids the coldness of pure minimalism by introducing warmth through material-inspired palettes and subtle depth, ensuring the user feels the "weight" and quality of the artisanal work.

The target audience seeks bespoke, high-value items; therefore, the UI must feel like a gallery experience rather than a standard e-commerce platform. Reliability is conveyed through structured grids, while the "high-quality" promise is fulfilled through generous whitespace and meticulous typographic hierarchy.

## Colors
The palette is a curated selection of forest and workshop tones. 
- **Primary (Walnut):** A deep, rich brown used for primary text and structural grounding.
- **Secondary (Gold Leaf):** A sophisticated gold accent used sparingly for calls to action, premium indicators, and decorative trims.
- **Tertiary (Mahogany):** A warmer, mid-tone brown used for hover states and secondary interactive elements.
- **Neutral (Cream/Parchment):** The primary background color, providing a soft, non-clinical canvas that feels more organic than pure white.
- **Contrast (Ebony):** Used for deep shadows and high-level headings to ensure legibility and a sense of permanence.

## Typography
This design system employs a classic Serif/Sans-serif pairing to balance tradition with modernity. **EB Garamond** brings an authoritative, literary quality to headings, suggesting a history of craftsmanship. **Manrope** provides a highly legible, clean counterpoint for functional text, ensuring the interface remains accessible and easy to navigate.

- **Display styles** should be used for hero sections and key narrative beats, often set in Walnut or Ebony.
- **Body text** should prioritize readability, using the Cream background to maintain high contrast without eye strain.
- **Label caps** are used for small metadata, categories, or "Overlines" above headings to add a touch of modern architectural detailing.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy on desktop to maintain a "contained" and curated feel, similar to an art catalog. 
- **Desktop:** A 12-column grid with a 1280px max-width. Large 64px outer margins create a frame around the content.
- **Mobile:** A 4-column grid with reduced margins (20px).
- **Rhythm:** Spacing follows an 8px incremental scale. Generous vertical padding (80px–120px) between sections is encouraged to allow the artisanal photography to "breathe."

Elements should often be offset or layered slightly to mimic physical objects placed on a surface, breaking the rigidity of a standard digital grid.

## Elevation & Depth
Depth is conveyed through **Ambient Shadows** and **Material Layering**. Instead of generic grey shadows, this design system utilizes low-opacity brown-tinted shadows (e.g., `#3D2B1F` at 8% opacity) to make elements feel as though they are resting on a wooden or cream-colored surface.

- **Surface Tiers:** Use subtle shifts in background color (from Cream to a slightly darker Beige) to define sections.
- **Backdrop Blurs:** Use frosted glass effects sparingly for navigation overlays to maintain a sense of lightness.
- **Soft Inner Glows:** On primary cards, a very faint inner gold stroke (0.5px) can be used to simulate a beveled edge or light catching the corner of a polished wood piece.

## Shapes
The shape language is **Soft (0.25rem)**. While organic textures are used in imagery, the UI containers maintain a structured, slightly softened edge to reflect the precision of a wood-carving chisel. 

- **Cards:** Use `rounded-lg` (0.5rem) to feel substantial but approachable.
- **Buttons:** Maintain the `0.25rem` radius for a sharp, professional finish.
- **Decorative Elements:** Circular elements (pill-shaped) are reserved exclusively for "Status" indicators or small chips to differentiate them from functional buttons.

## Components
- **Buttons:** The "Signature Button" features a Walnut background with a 1px Gold Leaf (`#C5A059`) border and Gold text. On hover, the background transitions to Mahogany with an increased outer glow.
- **Input Fields:** Use a minimalist "Underline" style or a very light Beige fill with a 1px Primary color bottom border. Labels should use the `label-caps` typography style.
- **Cards:** Product cards should have no visible border but use a subtle ambient shadow. The product name should always be in EB Garamond.
- **Chips/Tags:** Small, low-contrast elements with a Cream-darker fill and Primary text. No borders.
- **Gold Accents:** Use thin (1px) gold dividers to separate high-level sections or as decorative "brackets" around featured testimonials.
- **Specialty Component - 'The Grain Overlay':** A subtle, repeatable wood grain texture (PNG or SVG) should be applied at 3-5% opacity over the Primary and Tertiary color blocks to reinforce the wood-inspired theme.